package ir.nobitex.trader

import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var equity: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = 24
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Nobitex Trader"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 20, 0, 28)
        }
        root.addView(title)

        status = TextView(this).apply {
            text = "وضعیت: متوقف"
            textSize = 19f
            setPadding(0, 8, 0, 8)
        }
        root.addView(status)

        equity = TextView(this).apply {
            text = "Equity: —"
            textSize = 18f
            setPadding(0, 8, 0, 24)
        }
        root.addView(equity)

        val start = Button(this).apply {
            text = "شروع ربات (Paper)"
            setOnClickListener {
                status.text = "وضعیت: در حال اجرا — Paper"
                equity.text = "Equity: 100,000,000 تومان"
            }
        }
        root.addView(start, LinearLayout.LayoutParams(-1, -2))

        val stop = Button(this).apply {
            text = "توقف"
            setOnClickListener { status.text = "وضعیت: متوقف" }
        }
        root.addView(stop, LinearLayout.LayoutParams(-1, -2))

        val emergency = Button(this).apply {
            text = "توقف اضطراری"
            setOnClickListener {
                status.text = "وضعیت: توقف اضطراری"
            }
        }
        root.addView(emergency, LinearLayout.LayoutParams(-1, -2))

        val note = TextView(this).apply {
            text = "نسخه Build ابری اولیه است. کلید API نوبیتکس را داخل APK وارد نکنید."
            textSize = 14f
            setPadding(0, 28, 0, 0)
        }
        root.addView(note)

        setContentView(root)
    }
}
