package ir.nobitex.trader;
import android.app.*;import android.os.*;import android.graphics.Typeface;import android.text.InputType;import android.widget.*;import java.io.*;import java.net.*;import org.json.*;
public class MainActivity extends Activity{
 TextView st,eq,bal; EditText url,key,alloc;
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(28,35,28,25);
 TextView t=new TextView(this);t.setText("Nobitex Trader — Secure");t.setTextSize(25);t.setTypeface(null,Typeface.BOLD);r.addView(t);
 url=new EditText(this);url.setHint("آدرس HTTPS سرور");r.addView(url);
 key=new EditText(this);key.setHint("کلید کنترل سرور");key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);r.addView(key);
 alloc=new EditText(this);alloc.setHint("سرمایه اختصاصی ربات (تومان)");alloc.setInputType(InputType.TYPE_CLASS_NUMBER);r.addView(alloc);
 st=new TextView(this);st.setText("وضعیت: —");st.setTextSize(18);r.addView(st);eq=new TextView(this);eq.setText("Equity: —");eq.setTextSize(18);r.addView(eq);bal=new TextView(this);bal.setText("موجودی صرافی: —");bal.setTextSize(17);r.addView(bal);
 btn(r,"به‌روزرسانی / همگام‌سازی","/api/sync","POST");btn(r,"ثبت سرمایه اختصاصی","/api/allocation","POST");btn(r,"شروع ربات","/api/start","POST");btn(r,"توقف","/api/stop","POST");btn(r,"توقف اضطراری","/api/emergency","POST");
 TextView n=new TextView(this);n.setText("\nواریز پول به خود صرافی انجام می‌شود. این برنامه برداشت وجه را ندارد.\nکلید API نوبیتکس فقط روی سرور نگهداری می‌شود.");r.addView(n);setContentView(r); }
 void btn(LinearLayout r,String s,String p,String m){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->call(p,m));r.addView(b);}
 void call(String p,String m){new Thread(()->{try{URL u=new URL(url.getText().toString().replaceAll("/$","")+p);HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod(m);c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setRequestProperty("X-Control-Api-Key",key.getText().toString());c.setRequestProperty("Content-Type","application/json");if(m.equals("POST")){c.setDoOutput(true);if(p.equals("/api/allocation")){String a=alloc.getText().toString();c.getOutputStream().write(("{\"amount_irt\":"+(a.length()==0?"0":a)+"}").getBytes("UTF-8"));}else c.getOutputStream().write("{}".getBytes("UTF-8"));}int code=c.getResponseCode();InputStream is=code<400?c.getInputStream():c.getErrorStream();BufferedReader br=new BufferedReader(new InputStreamReader(is));StringBuilder s=new StringBuilder();String l;while((l=br.readLine())!=null)s.append(l);String out=s.toString();runOnUiThread(()->render(out,code));}catch(Exception e){runOnUiThread(()->st.setText("خطا: "+e.getMessage()));}}).start();}
 void render(String raw,int code){try{JSONObject j=new JSONObject(raw);if(j.has("running")){st.setText("وضعیت: "+(j.optBoolean("running")?"در حال اجرا":"متوقف")+" | "+j.optString("mode"));eq.setText("Equity: "+j.optDouble("equity",0));bal.setText("موجودی RLS صرافی: "+j.optDouble("exchange_rls",0));}else st.setText("پاسخ: "+raw);}catch(Exception e){st.setText("پاسخ سرور ("+code+")");}}
}
