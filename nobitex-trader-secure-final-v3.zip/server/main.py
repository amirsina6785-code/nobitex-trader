import os, time, threading, uuid, sqlite3
from datetime import datetime, timezone
from decimal import Decimal
import requests
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title='Nobitex Trader Secure v3')
CONTROL = os.getenv('CONTROL_API_KEY', '')
KEY = os.getenv('NOBITEX_API_KEY', '')
LIVE = os.getenv('LIVE_TRADING', 'false').lower() == 'true'
SYMBOL = os.getenv('SYMBOL', 'BTCIRT').upper()
POLL = max(10, int(os.getenv('POLL_SECONDS', '30')))
START = Decimal(os.getenv('STARTING_CASH_IRT', '100000000'))
RISK = Decimal(os.getenv('RISK_PER_TRADE', '0.005'))
MAXD = Decimal(os.getenv('MAX_DAILY_LOSS', '0.02'))
MAXP = Decimal(os.getenv('MAX_POSITION_PCT', '0.25'))
FAST = int(os.getenv('FAST_SMA', '9')); SLOW = int(os.getenv('SLOW_SMA', '21'))
TP = Decimal(os.getenv('TAKE_PROFIT_PCT', '0.02')); SL = Decimal(os.getenv('STOP_LOSS_PCT', '0.01'))
DB = os.getenv('STATE_DB', '/data/trader.db')

lock = threading.RLock(); prices = []

def db():
    os.makedirs(os.path.dirname(DB) or '.', exist_ok=True)
    c = sqlite3.connect(DB, check_same_thread=False)
    c.execute('CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT,time TEXT,side TEXT,price REAL,amount REAL,note TEXT,order_id TEXT)')
    c.commit(); return c
conn = db()

def load_state():
    defaults = {'running':False,'emergency':False,'mode':'LIVE' if LIVE else 'PAPER','cash':str(START),'asset':'0','entry':'','equity':str(START),'pnl':'0','day_start':str(START),'allocated_cash':str(START),'exchange_rls':'','exchange_btc':'','last_sync':'','last_error':'','last_action':'idle'}
    saved = {k:v for k,v in conn.execute('SELECT k,v FROM kv')}
    defaults.update(saved)
    for k in ('running','emergency'):
        defaults[k] = defaults[k] == '1'
    return defaults
state = load_state()

def persist():
    with lock:
        for k,v in state.items():
            val = '1' if isinstance(v,bool) and v else '0' if isinstance(v,bool) else str(v)
            conn.execute('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',(k,val))
        conn.commit()

def auth(k):
    if not CONTROL or not k or k != CONTROL: raise HTTPException(401, 'unauthorized')

def headers(): return {'Authorization':'Token '+KEY, 'User-Agent':'NobitexTrader/3.0 Secure'}

def book():
    r = requests.get(f'https://api.nobitex.ir/v3/orderbook/{SYMBOL}', timeout=10); r.raise_for_status(); d=r.json()
    return Decimal(str(d['asks'][0][0])), Decimal(str(d['bids'][0][0]))

def wallets():
    r=requests.get('https://api.nobitex.ir/users/wallets/list', headers=headers(), timeout=12); r.raise_for_status(); d=r.json()
    if d.get('status') != 'ok': raise RuntimeError(str(d))
    return {x['currency'].lower(): Decimal(str(x.get('activeBalance', x.get('balance','0')))) for x in d.get('wallets',[])}

def live_order(side, amount):
    if not LIVE: return {'id':'paper-'+uuid.uuid4().hex[:12]}
    if not KEY: raise RuntimeError('NOBITEX_API_KEY missing')
    base = SYMBOL[:-3].lower() if SYMBOL.endswith('IRT') else SYMBOL[:-4].lower()
    quote = 'rls' if SYMBOL.endswith('IRT') else 'usdt'
    payload = {'type':side, 'srcCurrency':base, 'dstCurrency':quote, 'amount':format(amount,'f'), 'execution':'market', 'clientOrderId':'nt-'+uuid.uuid4().hex[:16]}
    r=requests.post('https://api.nobitex.ir/market/orders/add', json=payload, headers=headers(), timeout=15); r.raise_for_status(); d=r.json()
    if d.get('status') != 'ok': raise RuntimeError(str(d))
    return d

def order_status(order_id):
    r=requests.post('https://api.nobitex.ir/market/orders/status', json={'id':int(order_id)}, headers=headers(), timeout=12); r.raise_for_status(); return r.json()

def sync_exchange():
    if not LIVE: return
    w=wallets(); base=SYMBOL[:-3].lower() if SYMBOL.endswith('IRT') else SYMBOL[:-4].lower(); quote='rls' if SYMBOL.endswith('IRT') else 'usdt'
    with lock:
        state['exchange_rls']=str(w.get(quote,Decimal('0'))); state['exchange_btc']=str(w.get(base,Decimal('0'))); state['last_sync']=datetime.now(timezone.utc).isoformat(); persist()

def log_trade(side,price,amount,note,oid):
    conn.execute('INSERT INTO trades(time,side,price,amount,note,order_id) VALUES(?,?,?,?,?,?)',(datetime.now(timezone.utc).isoformat(),side,float(price),float(amount),note,oid)); conn.commit()

def sma(a,n): return sum(a[-n:])/Decimal(n) if len(a)>=n else None

def loop():
    global prices
    while True:
        try:
            ask,bid=book(); mid=(ask+bid)/2; prices=(prices+[mid])[-200:]
            f=sma(prices,FAST); s=sma(prices,SLOW)
            with lock:
                cash=Decimal(state['cash']); asset=Decimal(state['asset']); entry=Decimal(state['entry']) if state['entry'] else None; allocated=Decimal(state['allocated_cash'])
                running=state['running'] and not state['emergency']; day=Decimal(state['day_start'])
            if LIVE and (not state['last_sync'] or time.time()%300 < POLL): sync_exchange()
            equity=cash+asset*mid
            if running:
                if equity < day*(1-MAXD):
                    with lock: state['running']=False; state['last_action']='daily loss stop'; persist()
                elif asset>0 and entry and (mid<=entry*(1-SL) or mid>=entry*(1+TP) or (f and s and f<s)):
                    res=live_order('sell',asset); oid=str(res.get('order',{}).get('id',res.get('id','unknown')))
                    fill=bid
                    with lock:
                        state['cash']=str(cash+asset*fill); state['asset']='0'; state['entry']=''; state['last_action']='sell'; log_trade('SELL',fill,asset,'exit',oid); persist()
                elif asset==0 and f and s and f>s:
                    available=min(cash,allocated,equity*MAXP); risk_cash=equity*RISK; amount=min(risk_cash/(mid*SL),available/mid)
                    if amount>0:
                        res=live_order('buy',amount); oid=str(res.get('order',{}).get('id',res.get('id','unknown')))
                        with lock:
                            state['cash']=str(cash-amount*ask); state['asset']=str(amount); state['entry']=str(ask); state['last_action']='buy'; log_trade('BUY',ask,amount,'SMA entry',oid); persist()
            with lock:
                state['equity']=str(equity); state['pnl']=str(equity-START); state['last_error']=''; persist()
        except Exception as e:
            with lock: state['last_error']=str(e); persist()
        time.sleep(POLL)

class Allocation(BaseModel): amount_irt:int=Field(gt=0, le=100_000_000_000)

@app.on_event('startup')
def startup(): threading.Thread(target=loop,daemon=True).start()
@app.get('/health')
def health(): return {'ok':True,'mode':state['mode']}
@app.get('/api/status')
def status():
    with lock: return dict(state)
@app.post('/api/sync')
def sync(x_control_api_key:str=Header(default='')):
    auth(x_control_api_key)
    if not LIVE: return {'ok':True,'mode':'PAPER','message':'Paper mode'}
    sync_exchange(); return status()
@app.post('/api/allocation')
def allocation(body:Allocation,x_control_api_key:str=Header(default='')):
    auth(x_control_api_key)
    if LIVE:
        sync_exchange()
        if body.amount_irt > int(Decimal(state['exchange_rls'] or '0')): raise HTTPException(400,'allocation exceeds free RLS balance')
    with lock: state['allocated_cash']=str(body.amount_irt); state['last_action']=f'allocation={body.amount_irt}'; persist()
    return status()
@app.post('/api/start')
def start(x_control_api_key:str=Header(default='')):
    auth(x_control_api_key)
    if LIVE and not KEY: raise HTTPException(400,'server has no Nobitex API key')
    with lock: state['emergency']=False; state['running']=True; state['last_action']='started'; persist()
    return status()
@app.post('/api/stop')
def stop(x_control_api_key:str=Header(default='')):
    auth(x_control_api_key)
    with lock: state['running']=False; state['last_action']='stopped'; persist()
    return status()
@app.post('/api/emergency')
def emergency(x_control_api_key:str=Header(default='')):
    auth(x_control_api_key)
    with lock: state['running']=False; state['emergency']=True; state['last_action']='EMERGENCY STOP'; persist()
    return status()
@app.get('/api/trades')
def trades(x_control_api_key:str=Header(default='')):
    auth(x_control_api_key); rows=conn.execute('SELECT time,side,price,amount,note,order_id FROM trades ORDER BY id DESC LIMIT 100').fetchall()
    return {'trades':[dict(zip(['time','side','price','amount','note','order_id'],r)) for r in rows]}
